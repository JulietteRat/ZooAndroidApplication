package com.ldnr.welovestephane;

import android.app.Activity;

public class CarteActivity extends Activity {

}
