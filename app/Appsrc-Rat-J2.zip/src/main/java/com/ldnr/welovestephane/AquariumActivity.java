package com.ldnr.welovestephane;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class AquariumActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(new AquariumView(this));
        Log.i("Aquarium","Activity Create");
        // Fait apparaitre un toast donc un message quand on lance l'application
    }

    public class AquariumView extends View {

        public AquariumView(Context context) {
            super(context);
        }
        @Override
        protected void onDraw(@NonNull Canvas canvas) {
            Bitmap bmp = BitmapFactory.decodeResource(getResources(), R.drawable.aquarium);
            canvas.drawBitmap(bmp, 0, 0, null);
        }
    }
}
