package com.ldnr.welovestephane;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class AlerteActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.alerte);
        }
    // Comment lire une donnée d'un composant d'un formulaire :
        public void envoyerClick(View v){
            String text =null;
            // Trouve l'EditText dans le layout alerte en utilisant son ID
            EditText et = findViewById(R.id.alerte_editText_intitule);
            // Prends le texte dans et :
            text = et.getText().toString();
            // Trouve la CheckBox dans le layout alerte en utilisant son ID
            CheckBox cb = findViewById(R.id.alerte_checkBox_urgent);
            // si la checbox est coché envoyé le msg dont l'id correspond a alerte_envois_urgent
            if (cb.isChecked() == true){
                Toast.makeText(this,getString(R.string.alerte_envois_urgent, text)
                        , Toast.LENGTH_LONG).show();
            }
            Toast.makeText(this,getString(R.string.alerte_envois, text)
                    , Toast.LENGTH_LONG).show();
    }
}

